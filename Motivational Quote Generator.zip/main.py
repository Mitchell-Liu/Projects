'''
Mitchell Hao Liu
Sept 10, 2020
'''

import random
i = random.randrange(0,5)
quotes = ["Rome did not create a great empire by having meetings, they did it by killing all people who opposed them.", "If you can stay calm, while all around you is chaos…then you probably haven’t completely understood the seriousness of the situation.", "Doing a job RIGHT the first time gets the job done. Doing the job WRONG fourteen times gives you job security.","Eagles may soar, but weasels don’t get sucked into jet engines.","Artificial Intelligence is no match for Natural Stupidity","A person who smiles in the face of adversity…probably has a scapegoat."]

answer = input("Would you like to see a motivational quote?: \n")
answer = answer.lower()
while answer != "no":
  if answer == "yes":
    print(quotes[i])
    answer = input("Would you like to see anoter motivational quote?: \n")
    answer = answer.lower()
    i = random.randrange(0,5)
  else:
    print("I don't understand what you mean. Please provide a yes or no answer: ")
    answer = input("Would you like to see a motivational quote?: \n")
    answer = answer.lower()
print("Goodbye")
