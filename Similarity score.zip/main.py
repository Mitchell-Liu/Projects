common = 0
print("Please enter hobbies, separated by spaces.")
hobbies1 = input("Person 1: ").split(" ")
hobbies2 = input("Person 2: ").split(" ")
for i in hobbies1:
  if i in hobbies2:
    common += 1
print("You have " + str(common) + " hobbies in common!")