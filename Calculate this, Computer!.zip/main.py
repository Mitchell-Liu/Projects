# Mitchell Liu
# Oct 6, 2020
# Clculate this, Computer!

# introduction
print("Hello there, I can tell you your average mood today")

# creates list
time_of_day = "morning,afternoon,evening".split(",")

days = 0
total_mood = 0

# loop to find the user's mood at three points in the day
for i in range(0,3):

    # checks if the input is a floating point number
    while True:
      try:
        mood = float(input("How were you feeling this {} on a scale from 1 to 10 ".format(time_of_day[i])))

        # makes it so the user can't input values greater than 10
        while mood > 10:
          print("Please enter a valid number")
          mood = float(input("How were you feeling this {} on a scale from 1 to 10 ".format(time_of_day[i])))
        
        # adds score to total score
        total_mood += float(mood)
        break
      except:
        print("Sorry that's not a valid number")
      
# caclulates average
avg_mood = round(total_mood/3,2)
print("Your average mood today has been " + str(avg_mood) +" out of 10")

# tests the average mood against other numbers
if int(avg_mood) > 6:
  print("Glad you're feeling good today!")
if int(avg_mood) < 7 and int(avg_mood) > 3:
  print("Pretty average day today")
if int(avg_mood) < 4:
  print("Sad to see you feel this way today :(")
