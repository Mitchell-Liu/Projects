score = 0
Q1 = input("Did you eat? ")
Q2 = input("Did you study? ")
Q3 = input("Did you do your laundry? ")
Q4 = input("Did you call grandma? ")
Q_all = [Q1, Q2, Q3, Q4]
for i in Q_all:
  if i == "yes":
    score += 1
if score == 0:
  print("0 points: I'm coming over.")
if score < 3:
  print("1-2 points: Ok.")
if score > 2:
  print("3-4 points: Good!")