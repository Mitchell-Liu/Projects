# ChatBot with Personality
# Author: Mitchell Liu
# Date: 9/20/2020

print("Hello there, I am Chatbot.")
answer1 = input("What is your name?\n").lower()
print("Hello: " + answer1.capitalize())
answer2 = input("How are you feeling today?:\n").lower()

g = ["good", "great", "wonderful", "excellent"]
b = ["bad", "terrible", "sad", "awful"]

if "not" in answer2:
  g, b = b, g
  i = 0
  while i !=4:
    if g[i] in answer2:
        print("That's great to hear!:)")
        break
    if b[i] in answer2:
      print("Sorry to hear about that.:(")
      break
    if i == 3:
      print("I don't understand")
      i = 0
      answer2 = input("How are you feeling today?:\n").lower()
    i = i + 1
else:
  i = 0
  while i !=4:
    if g[i] in answer2:
        print("That's great to hear!:)")
        break
    if b[i] in answer2:
      print("Sorry to hear about that.:(")
      break
    if i == 3:
      print("I don't understand")
      i = 0
      answer2 = input("How are you feeling today?:\n").lower()
    i = i + 1

answer3 = input("Would you like to talk about something?\n").lower()
while answer3 != "yes":
  if answer3 == "no":
    break
  answer3 = input("I'm sorry, could you reapeat that?\nWould you like to talk about something?\n").lower()
while answer3 == "yes":
  topic = input("What would you like to talk about?\n").lower()
  if topic == "the bee movie script":
    print("please visit https://web.njit.edu/~cm395/theBeeMovieScript/ to see the entire bee movie script")
    answer3 = input("Would you like to talk about something else?\n").lower()
  else:
    print("Sorry, I don't know that much about " + topic + ".")
    topic_ans = input("Would you like to tell me about it?\n").lower()
    if topic_ans == "yes":
      input()
      print("Thank you for telling me about that!")
      answer3 = input("Would you like to talk about something else?\n").lower()
    if topic_ans == "no" or topic_ans == "nope":
      print("Oh ok then")
      break


print("Goodbye.:)")