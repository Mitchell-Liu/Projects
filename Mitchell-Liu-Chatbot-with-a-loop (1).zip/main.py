# ChatBot with Personality
# Author: Mitchell Liu
# Date: 9/27/2020

import random
import sys

# introducing Chatbot
print("Hello there, I am Chatbot.")

# asking for user's name and greating them
answer1 = input("What is your name?\n").lower().strip(".,!?:; ")
print("Hello: {}" .format(answer1.capitalize()))

# first question: Asks how the user is doing
answer2 = input("How are you feeling today?:\n").lower().strip(".,!?:; ")

# list of positive and negative terms the program accepts
g = ["good", "great", "wonderful", "excellent"]
b = ["bad", "terrible", "sad", "awful"]

# checks if there is a "not" in frount of the answer so the program and respond accordingly
if "not" in answer2:
  
  # wwitches the good and bad terms
  g, b = b, g

  # setting i as a varible
  i = 0

  # a while loop that determins how the user is feeling
  while i !=4:

    # checking is a word in the list is in any of the user's input and responding accordingly
    if g[i] in answer2:
        print("I'm glad to hear that you're feeling {}!:)".format(answer2.lower().strip(".,!?:; ")))
        break
    if b[i] in answer2:
      print("I'm sorry to hear that you're feeling {}.:(".format(answer2.lower().strip(".,!?:; ")))
      break
    
    # used when the answer provided isn't in either of the lists
    if i == 3:
      print("I don't understand")
      i = -1
      answer2 = input("How are you feeling today?:\n").lower().strip(".,!?:; ")

    # adding 1 to i every 4 times it runs so the code can check for each word in both lists
    i = i + 1

# same code as before, but for when the answer doesn't have "not" in it
else:
  i = 0
  while i !=4:
    if g[i] in answer2:
        print("I'm glad to hear that you're feeling {}!:)".format(answer2.lower().strip(".,!?:; ")))
        break
    if b[i] in answer2:
      print("I'm sorry to hear that you're feeling {}.:(".format(answer2.lower().strip(".,!?:; ")))
      break
    if i == 3:
      print("I don't understand")
      i = -1
      answer2 = input("How are you feeling today?:\n").lower().strip(".,!?:; ")
    i = i + 1

# second question asking if the user wants to talk
answer3 = input("Would you like to talk about something?\n").lower().strip(".,!?:; ")

# loop for if the user says "yes" to wanting to talk about something
while answer3 == "yes":

  # asks what the user wants to talk about
  topic = input("What would you like to talk about?\n").lower().strip(".,!?:; ")

  # the only topic the program knows anything about
  if topic == "the bee movie script":
    
    # prints the website that has the entire bee movie script
    print("please visit https://web.njit.edu/~cm395/theBeeMovieScript/ to see the entire bee movie script")

    # asks if the user would like to talk about something else
    answer3 = input("Would you like to talk about something else?\n").lower().strip(".,!?:; ")

    # if the user enters anything other than the bee movie script
  else:
    print("Sorry, I don't know that much about " + topic + ".")
    topic_ans = input("Would you like to tell me about it?\n").lower().strip(".,!?:; ")
    if topic_ans == "yes":

      # the program allows the user to tell them about the topic they choose
      input()
      print("Thank you for telling me about that!")
      answer3 = input("Would you like to talk about something else?\n").lower().strip(".,!?:; ")

    # if the user doesn't want to talk about the subject, the program breaks
    elif topic_ans == "no" or topic_ans == "nope":
      print("Oh ok then")
      break

    # if the user types in something other than "yes" or "no"
    else:
      topic_ans = input("I'm sorry, could you repeat that?\n Would you like to tell me about it?\n")

# if the user doesn't answer "yes"
while answer3 != "yes":
  answer3 = input("I'm sorry, could you repeat that?\nWould you like to talk about something?\n").lower()

  # breaks if the user answers "no"
  if answer3 == "no":
    break

# question 3: asks the user to play a game
answer4 = input("Do you want to play a game?\n").lower().strip(".,!?:; ")

# sets the numbers used for the game
rand_num = [random.randrange(0,10),random.randrange(0,10),random.randrange(0,10)]

# a hidden variable that changes or stays the same depending if you win or lose
y = 0

# runs if the user wants to play the game
if answer4 == "yes":
  print("Guess 1 of 3 numbers I'm thinking of between 0 and 10, within 3 tries")
  
  # loop runs for each number in the random numbers list
  for x in rand_num:

    # the user guesses what numbers the program choose
    guess_num = input()

    # checking if the number the user choose is the same as the programs
    if int(guess_num) in rand_num:
      y = 1
      break
    
  # checks the hidden variable to see if the user won or loss
  if y == 0:
    print("You lose :(")
  if y == 1:
    print("You win!")

# if the user doesn't want to play the game
if answer4 == "no":
  print("Oh ok")

sys.exit("Goodbye.:)")