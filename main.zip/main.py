# Interactive Turtle Drawing
# Mitchell Liu
# 10/21/2020
# Draws three faces depending on mood

import turtle

# create a turtle object
t = turtle.Turtle()
t.shape("arrow")

# draws a smile
def smile(size):
  # scales width to size
  t.width(size)
  t.goto(0+y*int(size*80),0)
  t.pendown()
  # draws face
  t.circle(size*40)
  t.penup()
  # draws eyes
  t.goto(int(size*20)+y*int(size*80),(size*60))
  t.right(90)
  t.pendown()
  t.forward(size*20)
  t.penup()
  t.goto((size*-20)+y*int(size*80),(size*60))
  t.pendown()
  t.forward(size*20)
  t.penup()
  # draws smile
  t.goto((size*-20)+y*int(size*80),(size*30))
  t.pendown()
  for i in range(90):
    t.forward(size*0.7)
    t.left(2)
  # penup so that it doesn't draw a line between the first and second face
  t.penup()
  t.home()

# draws a frown
def frown(size):
  # scales width to size
  t.width(size)
  t.goto(0+y*int(size*80),0)
  t.pendown()
  # draws face
  t.circle(size*40)
  t.penup()
  # draws eyes
  t.goto(int(size*20)+y*int(size*80),(size*60))
  t.right(90)
  t.pendown()
  t.forward(size*20)
  t.penup()
  t.goto((size*-20)+y*int(size*80),(size*60))
  t.pendown()
  t.forward(size*20)
  t.penup()
  # draws frown
  t.goto((size*20)+y*int(size*80),(size*15))
  t.pendown()
  for i in range(90):
    t.back(size*0.7)
    t.left(2)
  # penup so that it doesn't draw a line between the first and second face
  t.penup()
  t.home()

# draws a meh face
def meh():
  t.width(5)
  t.goto(0+y*int(y*400),0)
  t.pendown()
  t.circle(200)
  t.penup()
  t.goto(y*int(y*400)+(100),(300))
  t.right(90)
  t.pendown()
  t.forward(100)
  t.penup()
  t.goto(y*int(y*400)+(-100),(300))
  t.pendown()
  t.forward(100)
  t.penup()
  t.goto(y*int(y*400)+(100),(100))
  t.pendown()
  t.right(90)
  t.forward(200)
  t.penup()
  t.goto(0,0)
  t.home()

i = 0
# the y variable exists to make sure the two drawn faces don't overlap
y = 0
# creates a list to be used later

list = "1,2,3,4,5,6,7,8,9,10"
list = list.split(",")
print(list[0])
print("This program will give you a accurate picture of your current expression")

# the main body
while i != 1:
  answer = input("Would you like to see your reflection? ").lower().strip("!,.?")
  # checks if the user wants to use the program
  if answer == "yes":

    mood = input("Do you feel Happy, Meh or Sad: ").lower().strip("!,.?")

    if mood == "happy":
      score = int(input("How {} do you feel on a scale from 1 to 10: ".format(mood)))
      # checks if the user put in a number from 1 to 10
      while str(score) not in list:
        score = input("Please enter a valid number: ")
      # calls the function twice
      for x in range(2):
        # calls the function
        smile(int(score))
        # increases distance between first face and second
        y+=1
      print("The left is footage from your camera, the right is the reflection")
      break

    elif mood == "sad":
      score = int(input("How {} do you feel on a scale from 1 to 10: ".format(mood)))
      # checks if the user put in a number from 1 to 10
      while str(score) not in list:
        score = input("Please enter a valid number: ")
      # calls the function twice
      for x in range(2):
        # calls the function
        frown(int(score))
        # increases distance between first face and second
        y+=1
      print("The left is footage from your camera, the right is the reflection")
      break


    elif mood == "meh":
      # calls the function twice
      for x in range(2):
        # calls the function
        meh()
        # increases distance between first face and second
        y+=1
      print("The left is footage from your camera, the right is the reflection")
      break
  # if the user doesn't want to use the program

  elif answer == "no":
    i += 1
  # if the user puts into another respons

  else:
    answer = input("Please enter a valid response. Would you like to see your reflection? ").lower().strip("!,.?")

print("Goodbye")
